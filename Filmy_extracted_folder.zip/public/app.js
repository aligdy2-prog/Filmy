const feed=document.getElementById("feed");

function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function money(n){return "€"+Number(n||0).toFixed(2)}

async function load(){
  const r=await fetch("/api/videos"); const videos=await r.json();
  feed.innerHTML=videos.map(v=>`
    <article class="card" data-id="${v.id}">
      ${v.videoUrl ? `<video src="${v.videoUrl}" controls playsinline></video>` : `<div class="placeholder">🎬</div>`}
      <div class="actions">
        <button onclick="likeVideo('${v.id}')">❤️</button>
        <button onclick="viewVideo('${v.id}')">👁️</button>
        <button onclick="share('${esc(v.title)}')">↗️</button>
      </div>
      <div class="meta"><h2>${esc(v.title)}</h2><p>${esc(v.description)} • ${(v.views||0).toLocaleString("ar") } مشاهدة</p></div>
    </article>`).join("");
  loadStats();
}
async function likeVideo(id){await fetch("/api/videos/"+id+"/like",{method:"POST"});load()}
async function viewVideo(id){await fetch("/api/videos/"+id+"/view",{method:"POST"});load()}
function share(title){if(navigator.share) navigator.share({title:"Filmy",text:title});else alert("يمكنك مشاركة رابط الصفحة من المتصفح");}
async function loadStats(){
  const r=await fetch("/api/admin/stats"),s=await r.json();
  document.getElementById("views").textContent=s.views.toLocaleString("ar");
  document.getElementById("likes").textContent=s.likes.toLocaleString("ar");
  document.getElementById("earnings").textContent=money(s.earnings);
}
document.getElementById("uploadForm").addEventListener("submit",async e=>{
  e.preventDefault(); const fd=new FormData(e.target);
  const r=await fetch("/api/upload",{method:"POST",body:fd}); const d=await r.json();
  document.getElementById("uploadMessage").textContent=d.error||"✅ تم رفع الفيديو";
  if(!d.error){e.target.reset();load();}
});
function go(name){
  document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));
  if(name==="feed"){feed.style.display="block";window.scrollTo(0,0)}
  else{feed.style.display="none";document.querySelectorAll(".panel")[name==="upload"?0:1].classList.add("active")}
}
load();
