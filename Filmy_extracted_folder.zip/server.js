const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA = path.join(ROOT, "data", "videos.json");
const UPLOADS = path.join(ROOT, "uploads");

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(ROOT, "public")));
app.use("/uploads", express.static(UPLOADS));

function readVideos() {
  try { return JSON.parse(fs.readFileSync(DATA, "utf8")); }
  catch { return []; }
}
function saveVideos(videos) {
  fs.writeFileSync(DATA, JSON.stringify(videos, null, 2));
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, Date.now() + "-" + Math.random().toString(36).slice(2) + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 250 * 1024 * 1024 },
  fileFilter: (_req, file, cb) =>
    file.mimetype.startsWith("video/") ? cb(null, true) : cb(new Error("فقط ملفات الفيديو مسموحة"))
});

app.get("/api/videos", (_req, res) => res.json(readVideos()));

app.post("/api/videos/:id/like", (req, res) => {
  const videos = readVideos();
  const v = videos.find(x => x.id === req.params.id);
  if (!v) return res.status(404).json({error:"الفيديو غير موجود"});
  v.likes = (v.likes || 0) + 1;
  saveVideos(videos);
  res.json(v);
});

app.post("/api/videos/:id/view", (req, res) => {
  const videos = readVideos();
  const v = videos.find(x => x.id === req.params.id);
  if (!v) return res.status(404).json({error:"الفيديو غير موجود"});
  v.views = (v.views || 0) + 1;
  // نموذج حساب فقط: لا يعتبر أموالاً حقيقية.
  v.creatorEarnings = Number(((v.views / 1000) * 0.5).toFixed(2));
  saveVideos(videos);
  res.json(v);
});

app.post("/api/upload", upload.single("video"), (req, res) => {
  if (!req.file) return res.status(400).json({error:"اختر فيديو"});
  const videos = readVideos();
  const item = {
    id: Date.now().toString(),
    title: req.body.title || "فيلم قصير",
    description: req.body.description || "",
    videoUrl: "/uploads/" + req.file.filename,
    views: 0,
    likes: 0,
    creatorEarnings: 0,
    createdAt: new Date().toISOString()
  };
  videos.unshift(item);
  saveVideos(videos);
  res.json(item);
});

app.get("/api/admin/stats", (_req, res) => {
  const videos = readVideos();
  res.json({
    videos: videos.length,
    views: videos.reduce((n,v)=>n+(v.views||0),0),
    likes: videos.reduce((n,v)=>n+(v.likes||0),0),
    earnings: Number(videos.reduce((n,v)=>n+(v.creatorEarnings||0),0).toFixed(2))
  });
});

app.use((err, _req, res, _next) => res.status(400).json({error: err.message || "حدث خطأ"}));

app.listen(PORT, () => console.log(`Filmy running on http://localhost:${PORT}`));
